import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Menu } from './pages/Menu';
import { Admin } from './pages/Admin';
import { Moderators } from './pages/Moderators';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Menu />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/moderators" element={<Moderators />} />
      </Routes>
    </Router>
  );
}

export default App;
