import { create } from 'zustand';
import { client } from '../api/client';

interface SettingsState {
  siteName: string;
  logoUrl: string | null;
  fetchSettings: () => Promise<void>;
  updateSettings: (settings: { siteName?: string; logoUrl?: string }) => Promise<void>;
}

export const useSettingsStore = create<SettingsState>((set) => ({
  siteName: 'გემრიელი', // Default
  logoUrl: null,
  fetchSettings: async () => {
    try {
      const res = await client.api.fetch('/api/public/settings');
      if (res.ok) {
        const data = await res.json();
        set({ 
          siteName: data.siteName || 'გემრიელი',
          logoUrl: data.logoUrl || null
        });
      }
    } catch (e) {
      console.error('Failed to fetch settings', e);
    }
  },
  updateSettings: async (settings) => {
    try {
      await client.api.fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      set((state) => ({ ...state, ...settings }));
    } catch (e) {
      console.error('Failed to update settings', e);
      throw e;
    }
  }
}));
