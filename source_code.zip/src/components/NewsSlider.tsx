import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Slide } from '../types';
import { client } from '../api/client';

export const NewsSlider: React.FC = () => {
  const [slides, setSlides] = useState<Slide[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const fetchSlides = async () => {
      try {
        const res = await client.api.fetch('/api/public/slides');
        if (res.ok) {
          const data = await res.json();
          setSlides(data.map((s: any) => ({ ...s, id: String(s.id) })));
        }
      } catch (e) {
        console.error('Failed to fetch slides', e);
      }
    };
    fetchSlides();
  }, []);

  useEffect(() => {
    if (slides.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [slides.length]);

  if (slides.length === 0) return null;

  return (
    <div className="relative w-full h-64 overflow-hidden rounded-2xl mb-6 bg-gray-100">
      <AnimatePresence initial={false} mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="absolute inset-0 w-full h-full"
        >
          {slides[currentIndex].type === 'video' ? (
            <video
              src={slides[currentIndex].url}
              className="w-full h-full object-cover"
              autoPlay
              muted
              loop
              playsInline
            />
          ) : (
            <img
              src={slides[currentIndex].url}
              alt={slides[currentIndex].title || 'Slide'}
              className="w-full h-full object-cover"
            />
          )}
          {slides[currentIndex].title && (
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
              <h3 className="text-white font-bold text-lg">{slides[currentIndex].title}</h3>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
      
      {slides.length > 1 && (
        <div className="absolute bottom-4 right-4 flex gap-2 z-10">
          {slides.map((_, idx) => (
            <div
              key={idx}
              className={`w-2 h-2 rounded-full transition-colors ${
                idx === currentIndex ? 'bg-white' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      )}
    </div>
  );
};
