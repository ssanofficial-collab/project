import React from 'react';
import { Category } from '../types';
import { clsx } from 'clsx';
import { 
  Utensils, 
  Soup, 
  Salad, 
  Coffee, 
  IceCream, 
  Flame, 
  Pizza, 
  Sandwich,
  Beef,
  Beer
} from 'lucide-react';

interface CategoryScrollerProps {
  categories: Category[];
  selectedId: string;
  onSelect: (id: string) => void;
}

const getIcon = (name: string) => {
  const lower = name.toLowerCase();
  if (lower.includes('სუპ')) return <Soup size={24} />;
  if (lower.includes('სალათ')) return <Salad size={24} />;
  if (lower.includes('სასმელ')) return <Coffee size={24} />; // Or Beer/Cup
  if (lower.includes('დესერტ')) return <IceCream size={24} />;
  if (lower.includes('მწვად')) return <Flame size={24} />;
  if (lower.includes('ხინკალ')) return <div className="font-bold text-lg">🥟</div>; // Custom emoji for Khinkali or generic
  if (lower.includes('პიცა')) return <Pizza size={24} />;
  if (lower.includes('ბურგერ')) return <Sandwich size={24} />;
  if (lower.includes('ხორც')) return <Beef size={24} />;
  if (lower.includes('ლუდ')) return <Beer size={24} />;
  return <Utensils size={24} />;
};

export const CategoryScroller: React.FC<CategoryScrollerProps> = ({
  categories,
  selectedId,
  onSelect,
}) => {
  return (
    <div className="sticky top-0 z-10 bg-white shadow-sm py-4">
      <div className="flex overflow-x-auto px-4 gap-6 no-scrollbar pb-2 snap-x">
        <button
          onClick={() => onSelect('all')}
          className="flex flex-col items-center gap-2 min-w-[70px] snap-start group"
        >
          <div className={clsx(
            "w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 shadow-sm",
            selectedId === 'all'
              ? "bg-orange-500 text-white shadow-orange-200 scale-110"
              : "bg-gray-100 text-gray-500 group-hover:bg-gray-200"
          )}>
            <Utensils size={24} />
          </div>
          <span className={clsx(
            "text-xs font-medium transition-colors",
            selectedId === 'all' ? "text-orange-600 font-bold" : "text-gray-500"
          )}>
            ყველა
          </span>
        </button>

        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => onSelect(category.id)}
            className="flex flex-col items-center gap-2 min-w-[70px] snap-start group"
          >
            <div className={clsx(
              "w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 shadow-sm overflow-hidden",
              selectedId === category.id
                ? "bg-orange-500 text-white shadow-orange-200 scale-110"
                : "bg-gray-100 text-gray-500 group-hover:bg-gray-200"
            )}>
              {category.image ? (
                <img src={category.image} alt={category.name} className="w-full h-full object-cover" />
              ) : (
                getIcon(category.name)
              )}
            </div>
            <span className={clsx(
              "text-xs font-medium transition-colors whitespace-nowrap",
              selectedId === category.id ? "text-orange-600 font-bold" : "text-gray-500"
            )}>
              {category.name}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};
