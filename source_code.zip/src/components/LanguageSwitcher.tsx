import React from 'react';
import { Languages } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export const LanguageSwitcher: React.FC = () => {
  const { i18n } = useTranslation();

  const toggleLanguage = () => {
    const newLang = i18n.language === 'ka' ? 'en' : 'ka';
    i18n.changeLanguage(newLang);
    localStorage.setItem('language', newLang);
  };

  return (
    <button
      onClick={toggleLanguage}
      className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
      title={i18n.language === 'ka' ? 'Switch to English' : 'ქართულად გადართვა'}
    >
      <Languages size={18} />
      <span className="uppercase">{i18n.language}</span>
    </button>
  );
};
