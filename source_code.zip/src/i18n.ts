import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  ka: {
    translation: {
      // Header
      cart: 'კალათა',
      
      // Menu Page
      popularDishes: 'პოპულარული კერძები',
      allCategories: 'ყველა კატეგორია',
      noDishesFound: 'ამ კატეგორიაში კერძები არ მოიძებნა',
      loading: 'იტვირთება...',
      
      // Product Card
      addToCart: 'კალათში დამატება',
      ingredients: 'ინგრედიენტები',
      hide: 'დამალვა',
      show: 'ჩვენება',
      edit: 'რედაქტირება',
      delete: 'წაშლა',
      deleteConfirm: 'ნამდვილად გსურთ წაშლა?',
      
      // Cart
      yourOrder: 'თქვენი შეკვეთა',
      emptyCart: 'კალათა ცარიელია',
      total: 'ჯამი',
      checkout: 'შეკვეთა',
      
      // Admin Panel
      adminPanel: 'ადმინ პანელი',
      productManagement: 'პროდუქტების მართვა',
      categoryManagement: 'კატეგორიების მართვა',
      siteSettings: 'საიტის პარამეტრები',
      newsSlides: 'სიახლეების სლაიდები',
      moderatorManagement: 'მოდერატორების მართვა',
      
      // Product Form
      addProduct: 'პროდუქტის დამატება',
      editProduct: 'პროდუქტის რედაქტირება',
      productName: 'დასახელება',
      description: 'აღწერა',
      price: 'ფასი',
      category: 'კატეგორია',
      selectCategory: 'აირჩიეთ კატეგორია',
      productImage: 'სურათი',
      addIngredient: 'ინგრედიენტის დამატება',
      save: 'შენახვა',
      cancel: 'გაუქმება',
      
      // Category Form
      addCategory: 'კატეგორიის დამატება',
      categoryName: 'დასახელება',
      categoryImage: 'სურათი',
      
      // Site Settings
      siteName: 'საიტის სახელი',
      siteLogo: 'ლოგო',
      
      // Slides
      addSlide: 'სლაიდის დამატება',
      slideTitle: 'სათაური',
      slideType: 'ტიპი',
      image: 'სურათი',
      video: 'ვიდეო',
      
      // Moderators
      inviteModerator: 'მოდერატორის მოწვევა',
      email: 'ელ. ფოსტა',
      password: 'პაროლი',
      accessCode: 'წვდომის კოდი',
      generateCode: 'კოდის გენერაცია',
      createAccount: 'ანგარიშის შექმნა',
      pendingApproval: 'დამტკიცების მოლოდინში',
      moderators: 'მოდერატორები',
      approve: 'დამტკიცება',
      reject: 'უარყოფა',
      role: 'როლი',
      status: 'სტატუსი',
      superAdmin: 'მთავარი ადმინი',
      moderator: 'მოდერატორი',
      pending: 'მოლოდინში',
      approved: 'დამტკიცებული',
      
      // Auth
      login: 'შესვლა',
      register: 'რეგისტრაცია',
      logout: 'გასვლა',
      enterCode: 'შეიყვანეთ კოდი',
      awaitingApproval: 'თქვენი ანგარიში მოლოდინშია. გთხოვთ დაელოდოთ ადმინისტრატორის დამტკიცებას.',
      accessDenied: 'წვდომა აკრძალულია',
      noAdminAccess: 'თქვენ არ გაქვთ ადმინ პანელზე წვდომის უფლება.',
      
      // Errors
      errorOccurred: 'შეცდომა მოხდა',
      errorVisibilityChange: 'შეცდომა სტატუსის შეცვლისას',
      errorDelete: 'შეცდომა წაშლისას',
      errorSave: 'შეცდომა შენახვისას',
      errorLoad: 'შეცდომა ჩატვირთვისას',
      
      // Common
      back: 'უკან',
      close: 'დახურვა',
      confirm: 'დადასტურება',
      upload: 'ატვირთვა',
      required: 'აუცილებელი',
    }
  },
  en: {
    translation: {
      // Header
      cart: 'Cart',
      
      // Menu Page
      popularDishes: 'Popular Dishes',
      allCategories: 'All Categories',
      noDishesFound: 'No dishes found in this category',
      loading: 'Loading...',
      
      // Product Card
      addToCart: 'Add to Cart',
      ingredients: 'Ingredients',
      hide: 'Hide',
      show: 'Show',
      edit: 'Edit',
      delete: 'Delete',
      deleteConfirm: 'Are you sure you want to delete?',
      
      // Cart
      yourOrder: 'Your Order',
      emptyCart: 'Cart is empty',
      total: 'Total',
      checkout: 'Checkout',
      
      // Admin Panel
      adminPanel: 'Admin Panel',
      productManagement: 'Product Management',
      categoryManagement: 'Category Management',
      siteSettings: 'Site Settings',
      newsSlides: 'News Slides',
      moderatorManagement: 'Moderator Management',
      
      // Product Form
      addProduct: 'Add Product',
      editProduct: 'Edit Product',
      productName: 'Name',
      description: 'Description',
      price: 'Price',
      category: 'Category',
      selectCategory: 'Select Category',
      productImage: 'Image',
      addIngredient: 'Add Ingredient',
      save: 'Save',
      cancel: 'Cancel',
      
      // Category Form
      addCategory: 'Add Category',
      categoryName: 'Name',
      categoryImage: 'Image',
      
      // Site Settings
      siteName: 'Site Name',
      siteLogo: 'Logo',
      
      // Slides
      addSlide: 'Add Slide',
      slideTitle: 'Title',
      slideType: 'Type',
      image: 'Image',
      video: 'Video',
      
      // Moderators
      inviteModerator: 'Invite Moderator',
      email: 'Email',
      password: 'Password',
      accessCode: 'Access Code',
      generateCode: 'Generate Code',
      createAccount: 'Create Account',
      pendingApproval: 'Pending Approval',
      moderators: 'Moderators',
      approve: 'Approve',
      reject: 'Reject',
      role: 'Role',
      status: 'Status',
      superAdmin: 'Super Admin',
      moderator: 'Moderator',
      pending: 'Pending',
      approved: 'Approved',
      
      // Auth
      login: 'Login',
      register: 'Register',
      logout: 'Logout',
      enterCode: 'Enter Code',
      awaitingApproval: 'Your account is pending approval. Please wait for administrator confirmation.',
      accessDenied: 'Access Denied',
      noAdminAccess: 'You do not have access to the admin panel.',
      
      // Errors
      errorOccurred: 'An error occurred',
      errorVisibilityChange: 'Error changing status',
      errorDelete: 'Error deleting',
      errorSave: 'Error saving',
      errorLoad: 'Error loading',
      
      // Common
      back: 'Back',
      close: 'Close',
      confirm: 'Confirm',
      upload: 'Upload',
      required: 'Required',
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: localStorage.getItem('language') || 'ka',
    fallbackLng: 'ka',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
