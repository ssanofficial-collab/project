export interface Category {
  id: string;
  name: string;
  image?: string;
}

export interface Product {
  id: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  image: string;
  ingredients: string[];
  isHidden?: boolean | number;
}

export interface Slide {
  id: string;
  type: 'image' | 'video';
  url: string;
  title?: string;
  sortOrder?: number;
}

export interface CartItem extends Product {
  quantity: number;
}
